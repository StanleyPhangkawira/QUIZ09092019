using System;

namespace QUIZ09092019
{
    0 references
    class Program
    {
        0 references
        static void Main(string[] args)
        {
            BangunDatar obj=new BangunDatar();

            obj.LuasPersegi();

            obj.LuasSegitiga();

            obj.LuasLingkaran();
        }
    }
}